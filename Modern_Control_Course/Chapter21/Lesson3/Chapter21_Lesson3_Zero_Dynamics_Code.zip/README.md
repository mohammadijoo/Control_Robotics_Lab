# Chapter 21, Lesson 3: Zero Dynamics and Internal System Behavior

This package contains source-code implementations for the lesson:

- `Chapter21_Lesson3.py`
- `Chapter21_Lesson3.cpp`
- `Chapter21_Lesson3.java`
- `Chapter21_Lesson3.m`
- `Chapter21_Lesson3.nb`

The common example is

\[
G(s)=\frac{s-1}{(s+1)(s+2)(s+3)}
\]

which has a right-half-plane transmission zero at \(z=+1\).  The scripts show that the output can be held at zero while the internal state grows according to \(\dot{\eta}=\eta\).
