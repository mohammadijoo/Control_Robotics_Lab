Chapter 15, Lesson 1: Definition of the Observability Gramian

Files:
- Chapter15_Lesson1.html: copyable Flask/Jinja lesson page.
- Chapter15_Lesson1.py: Python implementation using NumPy/SciPy.
- Chapter15_Lesson1.cpp: C++ implementation using Eigen.
- Chapter15_Lesson1.java: core Java implementation from scratch.
- Chapter15_Lesson1.m: MATLAB implementation with optional Simulink model generation.
- Chapter15_Lesson1.nb: Wolfram Mathematica notebook expression.

Generated for Control Engineering / ModernControl.
