Chapter18_Lesson5 code package

Files:
- Chapter18_Lesson5.py      Python / NumPy / SciPy implementation
- Chapter18_Lesson5.cpp     C++ / Eigen implementation
- Chapter18_Lesson5.java    Java from-scratch implementation
- Chapter18_Lesson5.m       MATLAB + optional Simulink implementation
- Chapter18_Lesson5.nb      Wolfram Mathematica notebook source

Topic:
Interpretation of Jordan form in control applications, including Jordan-chain responses,
controllability/observability ranks in Jordan coordinates, and practical interpretation of
input/output placement along generalized eigenvector chains.
