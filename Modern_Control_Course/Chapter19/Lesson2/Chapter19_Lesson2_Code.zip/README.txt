Chapter19 Lesson2 code package
================================

Files:
- Chapter19_Lesson2.py      NumPy/SciPy implementation of observability matrix, nullspace, and decomposition.
- Chapter19_Lesson2.cpp     C++/Eigen implementation.
- Chapter19_Lesson2.java    Java from-scratch RREF implementation.
- Chapter19_Lesson2.m       MATLAB/Control System Toolbox and optional Simulink model construction.
- Chapter19_Lesson2.nb      Wolfram Mathematica notebook-style code.

Topic: Chapter 19, Lesson 2 — Observable/Unobservable Subspaces.
