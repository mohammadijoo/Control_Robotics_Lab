Modern Control — Chapter 13 Lesson 1 package

Files:
- Chapter13_Lesson1.html
- Chapter13_Lesson1.py
- Chapter13_Lesson1.cpp
- Chapter13_Lesson1.java
- Chapter13_Lesson1.m
- Chapter13_Lesson1.nb

Topic:
Lesson 1: Intuitive Notion of Observability from Output Measurements
