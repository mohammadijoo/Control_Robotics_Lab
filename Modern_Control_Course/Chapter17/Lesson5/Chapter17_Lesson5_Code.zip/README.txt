Source-code package for Modern Control
Chapter 17: Observable and Modal Canonical Forms
Lesson 5: Practical Considerations in Choosing Canonical Forms

Files:
- Chapter17_Lesson5.py
- Chapter17_Lesson5.cpp
- Chapter17_Lesson5.java
- Chapter17_Lesson5.m
- Chapter17_Lesson5.nb

The examples compare physical/scaled coordinates, observable canonical coordinates, and modal coordinates using similarity transformations and conditioning proxies.
