# Chapter 12 Lesson 1 — Controllability Gramian

Files included:
- Chapter12_Lesson1.html
- Chapter12_Lesson1.py
- Chapter12_Lesson1.cpp
- Chapter12_Lesson1.java
- Chapter12_Lesson1.m
- Chapter12_Lesson1.nb
- Chapter12_Lesson1.wl

The HTML file follows the ModernControl template and embeds the same code shown in the downloadable source files.
