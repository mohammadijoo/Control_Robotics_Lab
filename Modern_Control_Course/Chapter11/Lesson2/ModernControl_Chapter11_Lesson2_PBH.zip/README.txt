Modern Control — Chapter 11, Lesson 2
PBH (Popov-Belevitch-Hautus) Test for Controllability

Files:
- Chapter11_Lesson2.html: copy-ready lesson template.
- Chapter11_Lesson2.py: NumPy PBH rank test.
- Chapter11_Lesson2.cpp: Eigen-based C++ PBH rank test.
- Chapter11_Lesson2.java: Apache Commons Math Java PBH rank test for real-eigenvalue examples.
- Chapter11_Lesson2.m: MATLAB implementation and Control System Toolbox comparison.
- Chapter11_Lesson2.nb: Wolfram Mathematica / Wolfram Language implementation.
