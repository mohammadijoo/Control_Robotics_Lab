Chapter 10 Lesson 3 Package
===========================

Course: Modern Control
Chapter 10: Controllability and Reachability – Concepts
Lesson 3: Finite-Time Reachability and Control Duration

Files:
- Chapter10_Lesson3.html
- Chapter10_Lesson3.py
- Chapter10_Lesson3.cpp
- Chapter10_Lesson3.java
- Chapter10_Lesson3.m
- Chapter10_Lesson3.nb
