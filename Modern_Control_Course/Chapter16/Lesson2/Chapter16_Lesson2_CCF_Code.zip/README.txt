Chapter 16 Lesson 2 Code Package
================================

Files:
- Chapter16_Lesson2.py     Python/Numpy implementation of CCF construction
- Chapter16_Lesson2.cpp    C++17 from-scratch implementation
- Chapter16_Lesson2.java   Java from-scratch implementation
- Chapter16_Lesson2.m      MATLAB implementation plus optional tf2ss comparison
- Chapter16_Lesson2.nb     Wolfram Mathematica code for CCF construction and verification

Topic:
Construction of Controllable Canonical Form from transfer-function data.
