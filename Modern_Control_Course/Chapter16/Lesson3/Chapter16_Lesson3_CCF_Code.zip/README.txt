Chapter16 Lesson3 CCF Package

Files:
- Chapter16_Lesson3.py     Python / NumPy implementation
- Chapter16_Lesson3.cpp    C++ standard-library implementation
- Chapter16_Lesson3.java   Java implementation
- Chapter16_Lesson3.m      MATLAB / Simulink-oriented script
- Chapter16_Lesson3.nb     Wolfram Mathematica code saved with .nb extension

Topic:
Properties of Controllable Canonical Form for analysis and design.
