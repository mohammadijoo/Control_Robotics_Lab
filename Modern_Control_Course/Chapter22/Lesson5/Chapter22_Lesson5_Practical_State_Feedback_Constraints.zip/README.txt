Chapter 22 Lesson 5 package for Modern Control.
Includes HTML plus Python, C++, Java, MATLAB/Simulink, and Wolfram Mathematica files.
