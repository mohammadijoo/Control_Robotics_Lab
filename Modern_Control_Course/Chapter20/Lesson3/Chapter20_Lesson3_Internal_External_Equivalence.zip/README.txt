Chapter 20 Lesson 3: Internal vs External Equivalence of Systems

Included files:
- Chapter20_Lesson3.html: Full HTML lesson page.
- Chapter20_Lesson3.py: Python implementation using NumPy.
- Chapter20_Lesson3.cpp: C++ implementation using Eigen 3.
- Chapter20_Lesson3.java: Java implementation from scratch.
- Chapter20_Lesson3.m: MATLAB script with optional Simulink model generation.
- Chapter20_Lesson3.nb: Wolfram Mathematica notebook wrapper.
- Chapter20_Lesson3_mathematica_source.txt: Plain Mathematica source for easy copy/paste.

Run examples:
Python:      python Chapter20_Lesson3.py
Java:        javac Chapter20_Lesson3.java && java Chapter20_Lesson3
C++:         g++ -std=c++17 Chapter20_Lesson3.cpp -I /path/to/eigen -O2 -o Chapter20_Lesson3
MATLAB:      run('Chapter20_Lesson3.m')
Mathematica: Open Chapter20_Lesson3.nb or paste the source text into a notebook.
